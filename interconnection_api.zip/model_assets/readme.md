# PJM Interconnection Cost Dataset – Cleaning & Construction

## 1. Overview

This document explains **how we built and cleaned the dataset** used to model interconnection upgrade costs in PJM.

We combine:

* **Project / queue data** (PJM / UMD interconnection dataset)
* **Real-time LMP (price) data** at the node level

and end up with a single, modeling-ready table where each row is a project, and columns include both project features and LMP-based grid condition features.

---

## 2. Source Data

### 2.1 Interconnection Queue Data

**File:**
`C:\lareg\Dataset\pjm\pjm_main_with_pnode_final.csv`

Main contents (one row per project):

* Project size: `energy_mw`, `capacity_mw`, `size_mw`
* Location: `state`, `county`, `lon_queue_noise`, `lat_queue_noise`
* Queue timing: `queue_date`, `queue_year`, `study1_wait`, `study2_wait`, `study3_wait`
* Queue context: various `queue_size_*` and `queue_sizemw_*` fields (total MW, battery MW, gas MW, etc.)
* Distances to substations / POI: `dist_matched_substation*`, `dist_poi*`, `min_dist_to_poi`, `dist_nearest_substation`
* Cost outcomes (in 2020 dollars): `total_cost_2020`, `poi_cost_2020`, `network_upgrade_cost_2020`, etc.
* Node link: `matched_pnode_id`, `matched_pnode_name`

### 2.2 Real-Time LMP Data

**Folder:**
`C:\lareg\Dataset\pjm\rt_da_monthly_lmps\`

Structure:

* One subfolder per **year** (e.g. `2014`, `2015`, …, `2025`)
* Inside each year folder: 12 monthly CSVs

Each LMP CSV contains:

* `datetime_beginning_utc`
* `pnode_id`
* `pnode_name`
* `total_lmp_rt` (real-time total LMP)

---

## 3. Cleaning the Interconnection Queue Dataset

**Input:**
`pjm_main_with_pnode_final.csv`
**Output:**
`pjm_queue_clean_for_model.csv`

### 3.1 Load and Select Target

* We load the full CSV (~8,941 rows, 123 columns).
* We choose **`total_cost_2020`** as the **target** we want to predict:

  * This is the inflation-adjusted total network upgrade cost in 2020 dollars.

### 3.2 Drop Columns That Leak the Target or Aren’t Usable

We remove columns that:

* Directly contain cost information we are trying to predict
  (to avoid data leakage), e.g.:

  * `total_cost`, `poi_cost`, `network_upgrade_cost`, `combined_cost`
  * All other cost fields with `_2020` or `_mw_2020`, etc.

* Depend on post-study outcomes that are not known at queue time, e.g.:

  * `generator_deliverability`, `multiple_facility_contingency`
  * `newsystem_reinforcement`, `prevsystem_reinforcement`
  * `short_circuit`, `system_protection_analysis`, `short_circuit_dynamic_analysis`
  * `new_substation`, `new_circuit_breaker`
  * Various hypothetical “prev_cost_*” and “prev_size_*” scenario fields

* Are just IDs or long text labels with little predictive value, e.g.:

  * `queue_number`, `developer`, `line`, `substation`, `poi_substation`
  * extra study IDs not needed for the model

We **keep**:

* `matched_pnode_id` (to link to LMP)
* `queue_year`
* Project/queue features we want to use as predictors:

  * size, fuel type, waits, queue sizes, distances, etc.

### 3.3 Filter to Valid Rows

We keep only rows where:

* `total_cost_2020` is present
* `matched_pnode_id` and `queue_year` are available

We also enforce reasonable types:

* `queue_year` → integer
* `matched_pnode_id` → nullable integer (`Int64`)

### 3.4 Save Cleaned Queue Data

After cleaning:

* Shape stays at **8,941 rows**, but with fewer columns (only the ones we need).
* Saved as:
  `C:\lareg\Dataset\pjm\pjm_queue_clean_for_model.csv`

This is the base table we use for modeling and for linking to LMP data.

---

## 4. Building LMP Features (Node–Year Aggregates)

**Input:**
All `rt_da_monthly_lmps\<YEAR>\*.csv` files
**Output:**
`pjm_lmp_node_year_stats.csv`

### 4.1 Read and Combine Hourly LMPs

* Loop over each year folder (2014–2025).
* For each monthly CSV, read **only**:

  * `datetime_beginning_utc`
  * `pnode_id`
  * `total_lmp_rt`
* Add a `year` column from the folder name.
* Concatenate all months/years into a single DataFrame.

Result:

* Combined ≈ **52 million** hourly records.
* Columns: `pnode_id`, `year`, `total_lmp_rt`.

### 4.2 Aggregate to Node–Year Statistics

For each `(pnode_id, year)` pair, compute:

* `rt_lmp_mean` – average real-time LMP
* `rt_lmp_std` – standard deviation (volatility)
* `rt_lmp_min` – minimum LMP
* `rt_lmp_max` – maximum LMP
* `rt_lmp_p05` – 5th percentile (low-end price level)
* `rt_lmp_p95` – 95th percentile (high-end price level)
* `rt_lmp_n_hours` – number of hourly observations

This collapses the huge hourly table to **one row per node-year**.

* Final table shape: ~16,716 rows.

### 4.3 Save Aggregated LMP Data

Saved as:
`C:\lareg\Dataset\pjm\pjm_lmp_node_year_stats.csv`

---

## 5. Joining Queue Data with LMP Features

**Goal:** give each project LMP context from its matched node.

**Inputs:**

* `pjm_queue_clean_for_model.csv`
* `pjm_lmp_node_year_stats.csv`

### 5.1 Define the Join Keys

For each project, we use:

* `matched_pnode_id` – identifies the pricing node.
* `queue_year` – the year the project entered the queue.
* We compute `prev_year = queue_year - 1`.

We deliberately use **LMP from the year *before* queue entry** to mimic what would have been known at the time (no future information leakage).

### 5.2 Perform the Merge

We merge:

* Left side: queue data, on `(matched_pnode_id, prev_year)`
* Right side: LMP data, on `(pnode_id, year)`

Then:

* Drop temporary columns `pnode_id`, `year` that came from LMP once the join is done.
* Drop rows where LMP features (e.g. `rt_lmp_mean`) are missing (no LMP info for that node-year).

Result:

* Final merged sample: **1,937 projects** that have both queue features and node-year LMP features.

This is our **modeling dataset**.


