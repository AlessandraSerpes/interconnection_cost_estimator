import pandas as pd
import json
import joblib
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from xgboost import XGBRegressor

# === 1. Load cleaned queue + LMP stats ===
queue_path = "pjm_queue_clean_for_model.csv"
lmp_path   = "pjm_lmp_node_year_stats.csv"

print("Loading data...")
dfq = pd.read_csv(queue_path, low_memory=False)
lmp = pd.read_csv(lmp_path)

print("Queue shape:", dfq.shape)
print("LMP stats shape:", lmp.shape)

# Ensure types match for join
dfq["matched_pnode_id"] = dfq["matched_pnode_id"].astype("Int64")
lmp["pnode_id"] = lmp["pnode_id"].astype("Int64")

# === 2. Use LMP from the year BEFORE queue_year ===
dfq["queue_year"] = dfq["queue_year"].astype(int)
dfq["prev_year"] = dfq["queue_year"] - 1

merged = dfq.merge(
    lmp,
    left_on=["matched_pnode_id", "prev_year"],
    right_on=["pnode_id", "year"],
    how="left"
)

print("Columns after merge:", merged.columns.tolist())

# Drop helper IDs
cols_to_drop_merge = [c for c in ["pnode_id", "year"] if c in merged.columns]
merged = merged.drop(columns=cols_to_drop_merge)

# Drop rows with no LMP info
before = merged.shape[0]
merged = merged.dropna(subset=["rt_lmp_mean"])
after = merged.shape[0]
print(f"Merged shape after dropping missing LMP: {before} -> {after}")

target_col = "total_cost_2020"
if target_col not in merged.columns:
    raise ValueError(f"Target column {target_col} not found in merged data!")

# === 3. Build X, y ===
y = merged[target_col].astype(float)

cols_not_features = [
    target_col,
    "issue_date",
    "queue_date",
    "matched_pnode_id",
    "prev_year",
]
cols_not_features = [c for c in cols_not_features if c in merged.columns]
X = merged.drop(columns=cols_not_features)

# Drop some ID-like text columns
extra_drop = ["cost_share_group", "nearest_substation",
              "nearest_matched_substation_id", "tapline"]
X = X.drop(columns=[c for c in extra_drop if c in X.columns])

# One-hot encode categoricals
cat_candidates = [
    "state", "fuel", "wind_solar", "fuel_prim",
    "study", "transmission_owner", "county", "network_allocation"
]
cat_cols = [c for c in cat_candidates if c in X.columns]
print("Categorical columns being one-hot encoded:", cat_cols)
X = pd.get_dummies(X, columns=cat_cols, drop_first=True)

# Drop any leftover non-numeric columns
non_numeric = X.select_dtypes(include=["object"]).columns.tolist()
if non_numeric:
    print("Dropping leftover non-numeric columns:", non_numeric)
    X = X.drop(columns=non_numeric)

# Fill NaNs
X = X.fillna(0)

print("Final feature matrix shape:", X.shape)

# === 4. Train/test split ===
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print("Train shapes:", X_train.shape, y_train.shape)
print("Test  shapes:", X_test.shape, y_test.shape)

# === 5. XGBoost model (no eval_metric in fit, older API safe) ===
model = XGBRegressor(
    n_estimators=600,
    learning_rate=0.05,
    max_depth=4,
    subsample=0.8,
    colsample_bytree=0.8,
    reg_lambda=1.0,
    objective="reg:squarederror",
    random_state=42,
    n_jobs=-1,
)

print("Training XGBRegressor...")
model.fit(X_train, y_train)

# === 6. Evaluate ===
y_pred = model.predict(X_test)

mae = mean_absolute_error(y_test, y_pred)
mse = mean_squared_error(y_test, y_pred)
rmse = mse ** 0.5
r2 = r2_score(y_test, y_pred)

print("\n=== XGBoost Model with LMP Features ===")
print(f"MAE : {mae:,.0f}")
print(f"RMSE: {rmse:,.0f}")
print(f"R²  : {r2:.3f}")

# === 7. Feature importance ===
importances = pd.Series(model.feature_importances_, index=X.columns)
print("\nTop 20 features:")
print(importances.sort_values(ascending=False).head(20))

# === 8. Save model and feature columns ===

joblib.dump(model, "pjm_xgb_model.joblib")

feature_columns = X.columns.tolist()
with open("feature_columns.json", "w") as f:
    json.dump(feature_columns, f)
