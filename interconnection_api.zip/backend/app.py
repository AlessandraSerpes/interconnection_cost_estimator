from fastapi import FastAPI
from pydantic import BaseModel
from pathlib import Path
import json
import joblib
import pandas as pd
import numpy as np
import xgboost as xgb
from typing import Optional

from fastapi import Query, HTTPException
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI(title="Interconnection Cost Estimator API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:5500",
        "http://localhost:5500",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# -------------------------
# Paths
# -------------------------
BASE_DIR = Path(__file__).resolve().parent
MODEL_DIR = BASE_DIR.parent / "model_assets"

MODEL_PATH = MODEL_DIR / "pjm_xgb_model_conformal.joblib"
FEAT_PATH  = MODEL_DIR / "feature_columns.json"
CONF_PATH  = MODEL_DIR / "conformal_params.json"

COUNTY_LOOKUP_PATH = MODEL_DIR / "county_pnode_lookup.csv"
STATE_LOOKUP_PATH  = MODEL_DIR / "state_pnode_lookup.csv"
STATE_YEAR_FALLBACK_PATH = MODEL_DIR / "state_year_lmp_fallback.csv"
LMP_STATS_PATH = MODEL_DIR / "pjm_lmp_node_year_stats.csv"
QUEUE_CLEAN_PATH = MODEL_DIR / "pjm_queue_clean_for_model.csv"

# ============================================================
# Load lookup tables (single source of truth)
# ============================================================

def load_lookups():
    cl = pd.read_csv(COUNTY_LOOKUP_PATH)
    sl = pd.read_csv(STATE_LOOKUP_PATH)
    syf = pd.read_csv(STATE_YEAR_FALLBACK_PATH)

    # normalize columns
    cl.columns = [c.lower().strip() for c in cl.columns]
    sl.columns = [c.lower().strip() for c in sl.columns]
    syf.columns = [c.lower().strip() for c in syf.columns]

    # normalize values
    cl["state"] = cl["state"].astype(str).str.upper().str.strip()
    cl["county"] = cl["county"].astype(str).str.strip()
    sl["state"] = sl["state"].astype(str).str.upper().str.strip()

    syf["state"] = syf["state"].astype(str).str.upper().str.strip()
    syf["year"] = pd.to_numeric(syf["year"], errors="coerce").astype("Int64")

    # LMP node-year stats
    lmp = pd.read_csv(LMP_STATS_PATH)
    lmp.columns = [c.lower().strip() for c in lmp.columns]
    lmp["pnode_id"] = pd.to_numeric(lmp["pnode_id"], errors="coerce").astype("Int64")
    lmp["year"] = pd.to_numeric(lmp["year"], errors="coerce").astype("Int64")

    idx = lmp.set_index(["pnode_id", "year"]).sort_index()

    return cl, sl, syf, idx


# -------------------------
# Globals loaded at startup
# -------------------------
model = None
feature_columns = None
ALPHA = None
QHAT = None

county_lookup = None
state_lookup = None
state_year_fallback = None
lmp_idx = None

dfq = None
queue_context_cols = None
distance_cols = None
mode_cols = None

state_year_medians = None
state_county_medians = None
state_county_modes = None
state_modes = None  # fallback when county missing

LMP_COLS = [
    "rt_lmp_mean", "rt_lmp_std", "rt_lmp_min",
    "rt_lmp_max", "rt_lmp_p05", "rt_lmp_p95",
    "rt_lmp_n_hours"
]

# -------------------------
# Request schema
# -------------------------
class PredictRequest(BaseModel):
    state: str
    county: str
    queue_year: int
    size_mw: float
    fuel: str
    pnode_id: Optional[int] = None

# -------------------------
# Helper: mode aggregator
# -------------------------
def mode_series(s: pd.Series):
    s = s.dropna()
    return s.mode().iloc[0] if not s.empty else None

# -------------------------
# Load lookups (from notebook)
# -------------------------
def load_lookups():
    cl = pd.read_csv(COUNTY_LOOKUP_PATH)
    sl = pd.read_csv(STATE_LOOKUP_PATH)
    syf = pd.read_csv(STATE_YEAR_FALLBACK_PATH)

    lmp = pd.read_csv(LMP_STATS_PATH)
    lmp["pnode_id"] = lmp["pnode_id"].astype("Int64")
    lmp["year"] = lmp["year"].astype(int)
    idx = lmp.set_index(["pnode_id", "year"])

    return cl, sl, syf, idx

def resolve_pnode_and_lmp(state: str, county: str, queue_year: int, pnode_id_input: int | None = None):

    """
    Mirrors notebook logic:
    - choose pnode by county, else state fallback
    - use prev_year for LMP
    - quality tiers based on rt_lmp_n_hours
    - fallback to state-year averages if needed
    """
    notes = []
    prev_year_raw = int(queue_year) - 1

    min_y = int(state_year_fallback["year"].min())
    max_y = int(state_year_fallback["year"].max())

    prev_year_used = max(min(prev_year_raw, max_y), min_y)

    if prev_year_used != prev_year_raw:
        notes.append(
            f"Requested LMP year {prev_year_raw} not covered by fallback table; "
            f"clamped to {prev_year_used}."
        )

    prev_year = int(prev_year_used)

    # 1) PNODE selection (optional user override)
    pnode_id = None

    if pnode_id_input is not None:
        # Only use user PNODE if it exists in our LMP index (so it can actually drive features)
        try:
            pnode_int = int(pnode_id_input)
            if lmp_idx is not None and pnode_int in lmp_idx.index.get_level_values(0):
                pnode_id = pnode_int
                notes.append("User-provided PNODE accepted.")
            else:
                notes.append("User-provided PNODE not recognized; ignored.")
        except Exception:
            notes.append("User-provided PNODE invalid; ignored.")

    if pnode_id is None:
        pnode_row = county_lookup[
            (county_lookup["state"] == state) &
            (county_lookup["county"] == county)
        ]
        if not pnode_row.empty:
            pnode_id = int(pnode_row.iloc[0]["matched_pnode_id"])
        else:
            notes.append("County not found; used state-level PNODE fallback.")
            st_row = state_lookup[state_lookup["state"] == state]
            if st_row.empty:
                raise ValueError(f"No PNODE mapping available for state={state}.")
            pnode_id = int(st_row.iloc[0]["matched_pnode_id"])


    # 2) LMP lookup (pnode_id, prev_year) with quality tiers
    lmp_features = None
    confidence = None

    try:
        row = lmp_idx.loc[(pnode_id, prev_year)]
        n_hours = float(row["rt_lmp_n_hours"])

        if n_hours >= 8000:
            lmp_features = {c: float(row[c]) for c in LMP_COLS}
            confidence = "high"
        elif n_hours >= 1000:
            lmp_features = {c: float(row[c]) for c in LMP_COLS}
            confidence = "medium"
            notes.append("Partial-year PNODE LMP used (medium confidence).")
        else:
            raise KeyError("Insufficient PNODE-year LMP coverage")

    except KeyError:
    # Try exact state-year fallback first
        fb = state_year_fallback[
            (state_year_fallback["state"] == state) &
            (state_year_fallback["year"] == prev_year)
        ]

        if fb.empty:
            # If state exists but not that year, pick nearest available year for that state
            fb_state = state_year_fallback[state_year_fallback["state"] == state]

            if not fb_state.empty:
                years = fb_state["year"].astype(int).unique().tolist()
                nearest_year = min(years, key=lambda y: abs(int(y) - int(prev_year)))
                fb = fb_state[fb_state["year"].astype(int) == int(nearest_year)]

                notes.append(
                    f"State-year LMP fallback missing for {state} in {prev_year}; "
                    f"used nearest available year {nearest_year} (low confidence)."
                )
                prev_year = int(nearest_year)  # keep meta consistent
            else:
                # State not present at all in fallback table -> global fallback by year (nearest if needed)
                notes.append(
                    f"No state-year LMP fallback available for state={state}; "
                    f"used global fallback (low confidence)."
                )

                # Try global for requested prev_year
                fb_global = state_year_fallback[state_year_fallback["year"].astype(int) == int(prev_year)]
                if fb_global.empty:
                    # Nearest year globally
                    all_years = state_year_fallback["year"].astype(int).unique().tolist()
                    nearest_year = min(all_years, key=lambda y: abs(int(y) - int(prev_year)))
                    fb_global = state_year_fallback[state_year_fallback["year"].astype(int) == int(nearest_year)]
                    notes.append(
                        f"Global fallback missing for year {prev_year}; used nearest year {nearest_year}."
                    )
                    prev_year = int(nearest_year)

                # Use mean across states for that year
                fb_row = fb_global[LMP_COLS].mean(numeric_only=True)

                lmp_features = {c: float(fb_row[c]) for c in LMP_COLS}
                confidence = "low"
                notes.append("Global LMP fallback used (low confidence).")
                return pnode_id, prev_year, lmp_features, notes, confidence

        # Normal state fallback path
        lmp_features = {c: float(fb.iloc[0][c]) for c in LMP_COLS}
        confidence = "low"
        notes.append("State-year LMP fallback used (low confidence).")


    return pnode_id, prev_year, lmp_features, notes, confidence

def build_X_one(user: dict):
    """
    Backend version of notebook build_X_one:
    - takes UI inputs
    - derives pnode + lmp
    - fills defaults via median/mode tables
    - one-hot encodes categoricals
    - aligns to feature_columns
    """
    state = user["state"]
    county = user["county"]
    queue_year = int(user["queue_year"])

    pnode_id, prev_year, lmp_feats, notes, confidence = resolve_pnode_and_lmp(
        state=state, county=county, queue_year=queue_year, pnode_id_input=user.get("pnode_id")
    )

    # --- Start row with required user inputs ---
    row = {
        "state": state,
        "county": county,
        "queue_year": queue_year,
        "size_mw": float(user["size_mw"]),
        "energy_mw": float(user.get("energy_mw", user["size_mw"])),
        "capacity_mw": float(user.get("capacity_mw", user["size_mw"])),
        "fuel": user.get("fuel", "Unknown"),
        "fuel_prim": user.get("fuel_prim", "Unknown"),
        "wind_solar": user.get("wind_solar", 0),
        "year": queue_year,  # matches notebook comment
    }

    # --- add LMP stats ---
    row.update(lmp_feats)

    # --- Queue context defaults by (state, queue_year) ---
    sy = state_year_medians[(state_year_medians["state"] == state) &
                            (state_year_medians["queue_year"] == queue_year)]
    if not sy.empty:
        for c in queue_context_cols:
            row[c] = float(sy.iloc[0][c]) if pd.notna(sy.iloc[0][c]) else 0.0
    else:
        # fallback: state-only median across years
        sy2 = state_year_medians[state_year_medians["state"] == state]
        if not sy2.empty:
            med = sy2[queue_context_cols].median(numeric_only=True)
            for c in queue_context_cols:
                row[c] = float(med[c]) if pd.notna(med[c]) else 0.0
        else:
            for c in queue_context_cols:
                row[c] = 0.0

    # --- Distance defaults by (state, county) ---
    sc = state_county_medians[(state_county_medians["state"] == state) &
                              (state_county_medians["county"] == county)]
    if not sc.empty:
        for c in distance_cols:
            row[c] = float(sc.iloc[0][c]) if pd.notna(sc.iloc[0][c]) else 0.0
    else:
        # fallback: state-only median
        sc2 = state_county_medians[state_county_medians["state"] == state]
        if not sc2.empty:
            med = sc2[distance_cols].median(numeric_only=True)
            for c in distance_cols:
                row[c] = float(med[c]) if pd.notna(med[c]) else 0.0
        else:
            for c in distance_cols:
                row[c] = 0.0

    # --- Mode categoricals by (state, county) ---
    scm = state_county_modes[(state_county_modes["state"] == state) &
                             (state_county_modes["county"] == county)]
    if not scm.empty:
        for c in mode_cols:
            row[c] = scm.iloc[0][c]
    else:
        # fallback: state-level mode
        sm = state_modes[state_modes["state"] == state]
        if not sm.empty:
            for c in mode_cols:
                row[c] = sm.iloc[0][c]
        else:
            for c in mode_cols:
                row[c] = None

    # --- Build DataFrame then one-hot encode ---
    X_one_raw = pd.DataFrame([row])

    cat_cols_present = [c for c in [
        "state", "county", "fuel", "fuel_prim",
        "study", "transmission_owner", "network_allocation"
    ] if c in X_one_raw.columns]

    X_one_enc = pd.get_dummies(X_one_raw, columns=cat_cols_present, drop_first=False)


    # Drop leftover non-numeric and fill
    non_numeric = X_one_enc.select_dtypes(include=["object"]).columns.tolist()
    if non_numeric:
        X_one_enc = X_one_enc.drop(columns=non_numeric)

    X_one_enc = X_one_enc.fillna(0)

    # Align to training schema
    X_one = X_one_enc.reindex(columns=feature_columns, fill_value=0)
    X_one.columns = X_one.columns.astype(str)

    return X_one.astype(float), notes, confidence, pnode_id, prev_year

# -------------------------
# Startup: load everything once
# -------------------------
@app.on_event("startup")
def startup():
    global model, feature_columns, ALPHA, QHAT
    global county_lookup, state_lookup, state_year_fallback, lmp_idx
    global dfq, queue_context_cols, distance_cols, mode_cols
    global state_year_medians, state_county_medians, state_county_modes, state_modes

    # artifacts
    model = joblib.load(MODEL_PATH)

    with open(FEAT_PATH, "r") as f:
        feature_columns = json.load(f)

    with open(CONF_PATH, "r") as f:
        conf = json.load(f)
    ALPHA = float(conf["alpha"])
    QHAT = float(conf["qhat"])

    # lookups
    county_lookup, state_lookup, state_year_fallback, lmp_idx = load_lookups()

    # queue defaults
    dfq = pd.read_csv(QUEUE_CLEAN_PATH, low_memory=False)
    dfq["queue_year"] = dfq["queue_year"].astype(int)

    queue_context_cols = [
        "queue_size_at_queue", "queue_sizemw_at_queue",
        "queue_size_battery", "queue_size_batterymw",
        "queue_size_wind", "queue_size_windmw",
        "queue_size_solar", "queue_size_solarmw",
        "queue_size_gas", "queue_size_gasmw",
        "queue_size_at_study1", "queue_sizemw_at_study1",
        "queue_size_at_study2", "queue_sizemw_at_study2",
        "study1_wait", "study2_wait", "study3_wait"
    ]
    queue_context_cols = [c for c in queue_context_cols if c in dfq.columns]

    state_year_medians = (
        dfq.groupby(["state", "queue_year"])[queue_context_cols]
           .median(numeric_only=True)
           .reset_index()
    )

    distance_cols = [
        "min_dist_to_poi", "dist_nearest_substation", "min_dist_to_matched_substation",
        "dist_matched_substation1", "dist_matched_substation2",
        "dist_matched_substation3", "dist_matched_substation4",
        "dist_poi1", "dist_poi2", "dist_poi3", "dist_poi4",
        "lon_queue_noise", "lat_queue_noise"
    ]
    distance_cols = [c for c in distance_cols if c in dfq.columns]

    state_county_medians = (
        dfq.groupby(["state", "county"])[distance_cols]
           .median(numeric_only=True)
           .reset_index()
    )

    mode_cols = ["study", "transmission_owner", "network_allocation", "tapline", "uprate", "study1_cost_share"]
    mode_cols = [c for c in mode_cols if c in dfq.columns]

    state_county_modes = (
        dfq.groupby(["state", "county"])[mode_cols]
           .agg(mode_series)
           .reset_index()
    )

    state_modes = (
        dfq.groupby(["state"])[mode_cols]
           .agg(mode_series)
           .reset_index()
    )

@app.get("/health")
def health():
    return {"status": "ok", "n_features": len(feature_columns), "qhat": QHAT, "alpha": ALPHA}

@app.post("/predict")
def predict(req: PredictRequest):
    try:
        user = req.dict()

        X_one, notes, confidence, pnode_id, prev_year = build_X_one(user)

        dmat = xgb.DMatrix(X_one.to_numpy(), feature_names=list(map(str, feature_columns)))
        pred = float(model.get_booster().predict(dmat)[0])

        low = max(pred - QHAT, 0.0)
        high = pred + QHAT
        nonzero = int((X_one.iloc[0] != 0).sum())

        return {
            "point_2020": pred,
            "low_2020": low,
            "high_2020": high,
            "alpha": ALPHA,
            "qhat": QHAT,
            "meta": {
                "pnode_id": pnode_id,
                "lmp_year_used": prev_year,
                "lmp_confidence": confidence,
                "notes": notes,
                "nonzero_features": nonzero
            }
        }

    except HTTPException:
        raise
    except ValueError as e:
        # Expected data/lookup issue
        raise HTTPException(status_code=422, detail=str(e))
    except Exception as e:
        # Unexpected bug
        raise HTTPException(status_code=500, detail=f"Internal error: {e}")


@app.get("/options/states")
def get_states():
    try:
        states = (
            county_lookup["state"]
            .dropna()
            .astype(str)
            .str.strip()
            .str.upper()
            .unique()
            .tolist()
        )
        states.sort()
        return {"states": states}
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to load states: {e}"
        )

@app.get("/options/counties")
def get_counties(state: str):
    try:
        st = state.strip().upper()

        subset = county_lookup[
            county_lookup["state"]
            .astype(str)
            .str.strip()
            .str.upper() == st
        ]

        counties = (
            subset["county"]
            .dropna()
            .astype(str)
            .str.strip()
            .unique()
            .tolist()
        )
        counties.sort()

        return {
            "state": st,
            "counties": counties
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to load counties for state={state}: {e}"
        )

@app.get("/options/fuels")
def get_fuels():
    fuels = sorted({
        c.replace("fuel_", "")
        for c in feature_columns
        if c.startswith("fuel_")
    })
    return {"fuels": fuels}

@app.get("/options/years")
def get_supported_queue_years():
    """
    Return queue years that are safe to use given LMP coverage.
    queue_year -> prev_year = queue_year - 1
    """
    # Prefer node-year stats if available
    years = None

    if lmp_idx is not None:
        # lmp_idx is indexed by (pnode_id, year)
        years = sorted({int(y) for (_, y) in lmp_idx.index})
    else:
        years = sorted(state_year_fallback["year"].astype(int).unique().tolist())

    if not years:
        return {"queue_years": []}

    min_prev = min(years)
    max_prev = max(years)

    queue_years = list(range(min_prev + 1, max_prev + 2))

    return {
        "queue_years": queue_years,
        "meta": {
            "prev_year_range": [min_prev, max_prev],
            "rule": "queue_year = prev_year + 1"
        }
    }

